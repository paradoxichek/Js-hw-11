//Задание 1

let name = 'Джон'


let admin

admin = name

console.log( admin);







//Задание 2


//Изначальный баланс

let balance = 25000


// Траты

let car = 4480
let food = 890



// Доходы

let invoice = 5500
let stock = 4200


// Вычисления

let траты =   car + food
let доходы = balance + invoice + stock



// Итоги

let totalBalance = доходы - траты


console.log( totalBalance);
