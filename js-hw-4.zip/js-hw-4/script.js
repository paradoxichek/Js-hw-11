
let temperature = 30;

if (temperature > 30) {
  console.log("жарко");
} else if (temperature > 15) {
  console.log("тепло");
} else {
  console.log("холодно");
}
